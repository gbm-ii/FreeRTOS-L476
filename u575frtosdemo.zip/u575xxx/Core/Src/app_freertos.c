/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : app_freertos.c
  * Description        : FreeRTOS applicative file
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "app_freertos.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
typedef StaticTask_t osStaticThreadDef_t;
typedef StaticQueue_t osStaticMessageQDef_t;
typedef StaticTimer_t osStaticTimerDef_t;
typedef StaticSemaphore_t osStaticSemaphoreDef_t;
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
static uint8_t inchar;


/* USER CODE END Variables */
/* Definitions for defaultTask */
osThreadId_t defaultTaskHandle;
const osThreadAttr_t defaultTask_attributes = {
  .name = "defaultTask",
  .priority = (osPriority_t) osPriorityNormal,
  .stack_size = 128 * 4
};
/* Definitions for ProcessTask */
osThreadId_t ProcessTaskHandle;
uint32_t MyBufferTask02[ 128 ];
osStaticThreadDef_t MycontrolBlocTask02;
const osThreadAttr_t ProcessTask_attributes = {
  .name = "ProcessTask",
  .stack_mem = &MyBufferTask02[0],
  .stack_size = sizeof(MyBufferTask02),
  .cb_mem = &MycontrolBlocTask02,
  .cb_size = sizeof(MycontrolBlocTask02),
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for OutputTask */
osThreadId_t OutputTaskHandle;
uint32_t MyBufferTask03[ 128 ];
osStaticThreadDef_t MycontrolBlocTask03;
const osThreadAttr_t OutputTask_attributes = {
  .name = "OutputTask",
  .stack_mem = &MyBufferTask03[0],
  .stack_size = sizeof(MyBufferTask03),
  .cb_mem = &MycontrolBlocTask03,
  .cb_size = sizeof(MycontrolBlocTask03),
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for BlueTimer */
osTimerId_t BlueTimerHandle;
osStaticTimerDef_t myTimerControlBlock01;
const osTimerAttr_t BlueTimer_attributes = {
  .name = "BlueTimer",
  .cb_mem = &myTimerControlBlock01,
  .cb_size = sizeof(myTimerControlBlock01),
};
/* Definitions for BtnTimer */
osTimerId_t BtnTimerHandle;
osStaticTimerDef_t myTimerControlBlock02;
const osTimerAttr_t BtnTimer_attributes = {
  .name = "BtnTimer",
  .cb_mem = &myTimerControlBlock02,
  .cb_size = sizeof(myTimerControlBlock02),
};
/* Definitions for InQueue */
osMessageQueueId_t InQueueHandle;
uint8_t myQueueBuffer01[ 16 * sizeof( uint16_t ) ];
osStaticMessageQDef_t myQueueControlBlock01;
const osMessageQueueAttr_t InQueue_attributes = {
  .name = "InQueue",
  .cb_mem = &myQueueControlBlock01,
  .cb_size = sizeof(myQueueControlBlock01),
  .mq_mem = &myQueueBuffer01,
  .mq_size = sizeof(myQueueBuffer01)
};
/* Definitions for OutQueue */
osMessageQueueId_t OutQueueHandle;
uint8_t myQueueBuffer02[ 16 * sizeof( uint16_t ) ];
osStaticMessageQDef_t myQueueControlBlock02;
const osMessageQueueAttr_t OutQueue_attributes = {
  .name = "OutQueue",
  .cb_mem = &myQueueControlBlock02,
  .cb_size = sizeof(myQueueControlBlock02),
  .mq_mem = &myQueueBuffer02,
  .mq_size = sizeof(myQueueBuffer02)
};
/* Definitions for OutBinarySem */
osSemaphoreId_t OutBinarySemHandle;
osStaticSemaphoreDef_t mybinarySemControlBlock01;
const osSemaphoreAttr_t OutBinarySem_attributes = {
  .name = "OutBinarySem",
  .cb_mem = &mybinarySemControlBlock01,
  .cb_size = sizeof(mybinarySemControlBlock01),
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */
  /* creation of OutBinarySem */
  OutBinarySemHandle = osSemaphoreNew(1, 1, &OutBinarySem_attributes);

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */
  /* creation of BlueTimer */
  BlueTimerHandle = osTimerNew(BlueTimerCallback, osTimerPeriodic, NULL, &BlueTimer_attributes);

  /* creation of BtnTimer */
  BtnTimerHandle = osTimerNew(BtnTimerCallback, osTimerPeriodic, NULL, &BtnTimer_attributes);

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  osTimerStart(BlueTimerHandle, BLUE_PERIOD);
  osTimerStart(BtnTimerHandle, BTN_TEST_PERIOD);
  /* USER CODE END RTOS_TIMERS */
  /* creation of InQueue */
  InQueueHandle = osMessageQueueNew (16, sizeof(uint16_t), &InQueue_attributes);
  /* creation of OutQueue */
  OutQueueHandle = osMessageQueueNew (16, sizeof(uint16_t), &OutQueue_attributes);

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */
  /* creation of defaultTask */
  defaultTaskHandle = osThreadNew(StartDefaultTask, NULL, &defaultTask_attributes);

  /* creation of ProcessTask */
  ProcessTaskHandle = osThreadNew(StartProcessTask, NULL, &ProcessTask_attributes);

  /* creation of OutputTask */
  OutputTaskHandle = osThreadNew(StartOutputTask, NULL, &OutputTask_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

}
/* USER CODE BEGIN Header_StartDefaultTask */
/**
* @brief Function implementing the defaultTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void *argument)
{
  /* USER CODE BEGIN defaultTask */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1000);
    HAL_GPIO_TogglePin(LED_RED_GPIO_Port, LED_RED_Pin);
  }
  /* USER CODE END defaultTask */
}

/* USER CODE BEGIN Header_StartProcessTask */
/**
* @brief Function implementing the ProcessTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartProcessTask */
void StartProcessTask(void *argument)
{
  /* USER CODE BEGIN ProcessTask */
	HAL_UART_Receive_IT(&huart1, &inchar, 1);
  /* Infinite loop */
  for(;;)
  {
	  uint16_t c;
	  osMessageQueueGet(InQueueHandle, &c, 0, osWaitForever);
	  if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'))
		  c ^= 'a' ^ 'A';
	  osMessageQueuePut(OutQueueHandle, &c, 0, osWaitForever);
  }
  /* USER CODE END ProcessTask */
}

/* USER CODE BEGIN Header_StartOutputTask */
/**
* @brief Function implementing the OutputTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartOutputTask */
void StartOutputTask(void *argument)
{
  /* USER CODE BEGIN OutputTask */
  /* Infinite loop */
  for(;;)
  {
	  uint16_t c;
	  osMessageQueueGet(OutQueueHandle, &c, 0, osWaitForever);
	  osSemaphoreAcquire(OutBinarySemHandle, osWaitForever);
	  HAL_UART_Transmit_IT(&huart1, (uint8_t *)&c, 1);
  }
  /* USER CODE END OutputTask */
}

/* BlueTimerCallback function */
void BlueTimerCallback(void *argument)
{
  /* USER CODE BEGIN BlueTimerCallback */
	HAL_GPIO_TogglePin(LED_BLUE_GPIO_Port, LED_BLUE_Pin);
  /* USER CODE END BlueTimerCallback */
}

/* BtnTimerCallback function */
void BtnTimerCallback(void *argument)
{
  /* USER CODE BEGIN BtnTimerCallback */
	static bool btn_was_pressed;
	bool btn_is_pressed = USER_BUTTON_GPIO_Port->IDR & USER_BUTTON_Pin;
	if (!btn_was_pressed && btn_is_pressed)
	{
		HAL_GPIO_TogglePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin);
	}
	btn_was_pressed = btn_is_pressed;
  /* USER CODE END BtnTimerCallback */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	osMessageQueuePut(InQueueHandle, &inchar, 0, 0);
	HAL_UART_Receive_IT(&huart1, &inchar, 1);
}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
	osSemaphoreRelease(OutBinarySemHandle);
}

/* USER CODE END Application */

